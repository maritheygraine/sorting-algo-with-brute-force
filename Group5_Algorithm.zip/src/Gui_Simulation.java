
import java.awt.Color;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author dell
 */
public class Gui_Simulation extends javax.swing.JFrame {
    int num = 1;
    int num2 = 1;

    /**
     * Creates new form Gui_Simulation
     */
    public Gui_Simulation() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        jScrollPane1.setOpaque(false);
        jScrollPane1.getViewport().setOpaque(false);
        jScrollPane1.setBorder(null);
        jScrollPane1.setViewportBorder(null);
        
        
        output.setBackground(new Color(0,0,0,10));
        output.setBorder(null);
        
        
        
        
         Thread t1 = new Thread(new Runnable(){
            @Override
            public void run(){
                
                
                
    // INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION             
                   if (Gui_Menu.activeInsertion == 1){
          
           int[] dataArr = new int[Gui_Input.inputArray.size()];
            
           for (int i =0; i<Gui_Input.inputArray.size(); i++){
               dataArr[i] = Gui_Input.inputArray.get(i);
               }
           System.out.println("Ascending");
           output.append("Ascending: \n");
        for (int i = 0; i<dataArr.length; i++) {
            for(int j = i+1; j < dataArr.length; j++){
                if(dataArr[i]>dataArr[j]){
                    int temp;
                    temp = dataArr[i];
                    dataArr[i]=dataArr[j];
                    dataArr[j]=temp;
                    
                }
            }
            
            for(int x=0; x < dataArr.length; x++){  
                try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            } 
                System.out.print(dataArr[x] + " "); 
                output.append("" + dataArr[x] + " ");
            } 
                try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            } 
                
        System.out.println();
        output.append("\n");
        }
        
        System.out.println("Descending");
        output.append("Descending: \n");
        for (int i = 0; i<dataArr.length; i++) {
            for(int j = i+1; j < dataArr.length; j++){
                if(dataArr[i]<dataArr[j]){
                    int temp;
                    temp = dataArr[i];
                    dataArr[i]=dataArr[j];
                    dataArr[j]=temp;
                }
            }
            for(int y=0; y < dataArr.length; y++){  
                    try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
                output.append(dataArr[y] + " ");
                System.out.print(dataArr[y] + " ");  
            } 
        System.out.println();
        output.append("\n");
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
        
        System.out.println("\n\nFINAL:");  
        output.append("\n\nFINAL PASS: \n");
        for(int b=0; b < dataArr.length; b++){  
                System.out.print(dataArr[b] + " ");  
                output.append("" + dataArr[b] + " ");
            } 
        System.out.println();
        output.append("\n");
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            } 
            
    }
// INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION INSERTION  
//
// BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT 

                   else if(Gui_Menu.activeBubble == 1){
                        int[] dataArr = new int[Gui_Input.inputArray.size()];
            
           for (int i =0; i<Gui_Input.inputArray.size(); i++){
               dataArr[i] = Gui_Input.inputArray.get(i);
               }
                        System.out.println("Bubble Sort Ascending");
                        output.append(" " + "Bubble Sort Ascending\n");
        for (int i = dataArr.length; i>1; i--) {
            for(int j = 0; j < i-1; j++){
                if(dataArr[j]>dataArr[j+1])
                {
                    int swap = dataArr[j];
                    dataArr[j]=dataArr[j+1];
                    dataArr[j+1]=swap;
                }
            }
            for(int x=0; x < dataArr.length; x++)
            {  
                   try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
                System.out.print(dataArr[x] + " ");  
                output.append(" " + dataArr[x] + " ");
            } 
                   try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
        System.out.println();
        output.append("\n");
        }
        
        System.out.println("Bubble Sort Descending");
        output.append("Bubble Sort Descending: \n");
        for (int i = dataArr.length; i>1; i--) {
            for(int j = 0; j < i-1; j++){
                if(dataArr[j]<dataArr[j+1])
                {
                    int swap = dataArr[j];
                    dataArr[j]=dataArr[j+1];
                    dataArr[j+1]=swap;
                }
            }
            for(int y=0; y < dataArr.length; y++){  
                   try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
                System.out.print(dataArr[y] + " ");  
                output.append(" " + dataArr[y] + " ");
            } 
                   try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
        System.out.println();
        output.append("\n");
        }
        
        System.out.println("\n\nFINAL:");  
        output.append("\n\nFINAL PASS:");
        for(int b=0; b < dataArr.length; b++)
        {  
               try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
                System.out.print(dataArr[b] + " ");  
                output.append(" " + dataArr[b] + " ");
            } 
        System.out.println();
        output.append("\n");
                   }
  // BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT BUBBLE SORT 
  // 
  // SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT 
            
                   else if(Gui_Menu.activeSelection == 1){
          int[] dataArr = new int[Gui_Input.inputArray.size()];
          
           for (int i =0; i<Gui_Input.inputArray.size(); i++){
               dataArr[i] = Gui_Input.inputArray.get(i);
               }
                       System.out.println("Ascending");
                       output.append("Ascending: \n");
        for (int i = 0; i < dataArr.length - 1; i++) {
            int minElementIndex = i;
                for (int j = i + 1; j < dataArr.length; j++) {
                    if (dataArr[minElementIndex] > dataArr[j]) {
                        minElementIndex = j;
                    }
                }
 
                if (minElementIndex != i) {
                    int temp = dataArr[i];
                    dataArr[i] = dataArr[minElementIndex];
                    dataArr[minElementIndex] = temp;
                }
                
            for(int x=0; x < dataArr.length; x++){  
                       try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
                System.out.print(dataArr[x] + " ");  
                output.append(""+ dataArr[x] + " ");
            } 
                   try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println();
            output.append("\n");
        }
        
        
        System.out.println("Descending");
        output.append("Descending: \n");
        for (int i = 0; i < dataArr.length - 1; i++) {
            int maxElementIndex = i;
            for (int j = i + 1; j < dataArr.length; j++) {
                if (dataArr[maxElementIndex] < dataArr[j]) {
                    maxElementIndex = j;
                    }
            }
 
            if (maxElementIndex != i) {
                int temp = dataArr[i];
                dataArr[i] = dataArr[maxElementIndex];
                dataArr[maxElementIndex] = temp;
            }
            for(int x=0; x < dataArr.length; x++){  
                       try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
                System.out.print(dataArr[x] + " ");  
                output.append("" + dataArr[x] + " ");
            } 
                   try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println();
            output.append("\n");
        }
        
        
        System.out.println("\n\nFINAL:");  
        output.append("\n\nFINAL pass: \n");
        for(int b=0; b < dataArr.length; b++){ 
                   try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
                output.append("" + dataArr[b] + " ");
                System.out.print(dataArr[b] + " ");  
            } 
               try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
              //  Logger.getLogger(SieveOfEratosthenes.class.getName()).log(Level.SEVERE, null, ex);
            }
        System.out.println();
        output.append("\n");
                   }
  
 // SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT 
 //
 // SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT SELECTION SORT 
     
// HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  
//
// HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  HEAP SORT  
                   else if (Gui_Menu.activeHeap == 1){
                        int[] arrayInput = new int[Gui_Input.inputArray.size()];
          
           for (int i =0; i<Gui_Input.inputArray.size(); i++){
               arrayInput[i] = Gui_Input.inputArray.get(i);
               }
                        System.out.println("Before Ascending Heap Sort: "); 
                        output.append("Before Ascending Heap Sort: \n");
                    printArray(arrayInput);
                    
                    System.out.println("Passes:");  
                    output.append("Passes: \n");
                

                  

                System.out.println("FINAL SORT:");  
                    printArray(arrayInput);   
                 
               
                System.out.println("\n\nBefore Descending Heap Sort ");
                output.append("\nBefore Descending Heap Sort \n");
                    printArray(arrayInput);
                    
                    System.out.println("Passes:");   
                    output.append("\nPasses: \n");
                


                System.out.println("FINAL SORT:");  
                output.append("FINAL SORT\n");
                    printArray(arrayInput); 
                    
                   }
 
 
                
        }
        
            
        });
        t1.start();
  
            }
    
      public void part(int arrayInput[], int n, int i) { 
        
        int smallestRoot = i; 
        int leftChild = 2*i + 1; 
        int rightChild = 2*i + 2; 
        
        
            if (leftChild < n && arrayInput[leftChild] > arrayInput[smallestRoot]) 
                smallestRoot = leftChild; 

            if(rightChild < n && arrayInput[rightChild] > arrayInput[smallestRoot]) 
                smallestRoot = rightChild; 

            if (smallestRoot != i){ 
                int temp = arrayInput[i]; 
                arrayInput[i] = arrayInput[smallestRoot]; 
                arrayInput[smallestRoot] = temp; 
                part(arrayInput, n, smallestRoot); 
            } 
         
        //To Print Passes
            printArray(arrayInput); 

    } 
    
     public void partdesc(int arrayInput[], int n, int i) { 
        
        int smallestRoot = i; 
        int leftChild = 2*i + 1; 
        int rightChild = 2*i + 2; 
        
        
            if (leftChild < n && arrayInput[leftChild] < arrayInput[smallestRoot]) 
                smallestRoot = leftChild; 

            if(rightChild < n && arrayInput[rightChild] < arrayInput[smallestRoot]) 
                smallestRoot = rightChild; 

            if (smallestRoot != i){ 
                int temp = arrayInput[i]; 
                arrayInput[i] = arrayInput[smallestRoot]; 
                arrayInput[smallestRoot] = temp; 
                partdesc(arrayInput, n, smallestRoot); 
            } 
         
        //To Print Passes
            printArray(arrayInput); 

    } 
    
    

    public void hsort(int arrayInput[]){ 
        int n = arrayInput.length; 
  
        for (int i = n / 2 - 1; i >= 0; i--) // Build heap 
            part(arrayInput, n, i); 
            
        //Identify root and put in last
        for (int i=n-1; i>=0; i--){   
            int temp = arrayInput[0]; 
            arrayInput[0] = arrayInput[i]; 
            arrayInput[i] = temp; 
            part(arrayInput, i, 0); 
            
            
        } 
    } 
    
     public void hdescsort(int arrayInput[]){ 
        int n = arrayInput.length; 
  
        for (int i = n / 2 - 1; i >= 0; i--) // Build heap 
            partdesc(arrayInput, n, i); 
            
        //Identify root and put in last
        for (int i=n-1; i>=0; i--){   
            int temp = arrayInput[0]; 
            arrayInput[0] = arrayInput[i]; 
            arrayInput[i] = temp; 
            partdesc(arrayInput, i, 0); 
            
            
        } 
    } 
    
    static void printArray(int[] arrayInput){
	    
        for(int i=0; i < arrayInput.length; i++){  
            System.out.print(arrayInput[i] + " ");  
        } 
        System.out.println();  
    }
       

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        output = new javax.swing.JTextArea();
        btnBack = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        output.setEditable(false);
        output.setBackground(new java.awt.Color(255, 153, 102));
        output.setBackground(Color.decode("#7F462C"));
        output.setColumns(20);
        output.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        output.setForeground(new java.awt.Color(255, 255, 255));
        output.setLineWrap(true);
        output.setRows(5);
        jScrollPane1.setViewportView(output);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 370, 210));

        btnBack.setFont(new java.awt.Font("Kristen ITC", 1, 24)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("Back to Menu");
        btnBack.setContentAreaFilled(false);
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBackMouseClicked(evt);
            }
        });
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel1.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 460, -1, -1));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CloseButton.png"))); // NOI18N
        jButton2.setContentAreaFilled(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 10, 100, 90));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\dell\\Desktop\\SortingProj\\wood_board.png")); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 450, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\dell\\Desktop\\SortingProj\\Algo_Simulation.gif")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 513));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        new Gui_Menu().setVisible(true);
        Gui_Menu.activeBubble = 0;
        Gui_Menu.activeInsertion = 0;
        Gui_Menu.activeSelection = 0;
        Gui_Menu.activeHeap = 0;
        Gui_Input.inputArray.clear();
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBackMouseClicked
        Gui_Menu menu = new Gui_Menu();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        int confirm = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to exit?", "Exit", JOptionPane.CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if(confirm == 0){
            this.dispose();
        }
    }//GEN-LAST:event_jButton2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Gui_Simulation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Gui_Simulation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Gui_Simulation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gui_Simulation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Gui_Simulation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea output;
    // End of variables declaration//GEN-END:variables
}
